package com.lti.exception;

public class InsuranceServiceException extends Exception {

	public InsuranceServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InsuranceServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InsuranceServiceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InsuranceServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InsuranceServiceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
