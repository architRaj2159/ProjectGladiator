package com.lti.dto;

public class ForgotPasswordStatus extends StatusDto {
	private String email;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
