package com.lti.service;

import com.lti.entity.Policy;

public interface RenewService {

	String renewIns(Policy policy);

}