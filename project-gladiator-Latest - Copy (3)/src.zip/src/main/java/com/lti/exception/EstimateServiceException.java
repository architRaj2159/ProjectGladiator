package com.lti.exception;

public class EstimateServiceException extends RuntimeException{

	public EstimateServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EstimateServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public EstimateServiceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public EstimateServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public EstimateServiceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	



}
