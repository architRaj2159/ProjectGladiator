package com.lti.dto;

public class GetAllClaims {
	private int sessionId;

	public int getSessionId() {
		return sessionId;
	}

	public void setSessionId(int sessionId) {
		this.sessionId = sessionId;
	}
	
	
}
